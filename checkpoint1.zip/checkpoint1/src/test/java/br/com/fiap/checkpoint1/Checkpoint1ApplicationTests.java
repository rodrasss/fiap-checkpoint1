package br.com.fiap.checkpoint1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Checkpoint1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
